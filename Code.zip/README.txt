Title:MSFA-Net: An Advanced Deep Learning Model for Identifying Blue Horizontal-Branch Stars from LAMOST DR12

Authors: Mingyuan Wang, Xiaoming Kong, Jie Ju, Yude Bu, and Yuchen Liang

Description of contents: This repository contains the scripts used to train and fine-tune the MSFA-Net model for stellar spectral classification. The workflow consists of two stages: Stage 1 pre-training on a multi-class stellar classification task, and Stage 2 fine-tuning on a binary BHB-versus-non-BHB classification task.
	· msfanet_stage1_pretrain.py: Stage-1 pre-training script. It implements the MSFA-Net architecture for multi-class stellar spectral classification and saves the optimized base feature weights. The script includes the following key modules:
		· MultiScaleBlock: Extracts multiscale spectral features using parallel 1D convolutions with varying receptive fields.
		· SoftFrequencyAttention: An attention mechanism operating in the frequency domain via Fast Fourier Transform to dynamically weight different frequency bands.
		· EnhancedSPP: Extracts robust global representations by computing diverse statistical features across multiple pooling bins.
		· SpectralDataset: A custom PyTorch dataset that handles data type conversions and automatically patches numerical anomalies in the input spectra.
		· W-LSCE Loss: A customized loss function combining label smoothing and dynamic class weights to mitigate data imbalance and model overconfidence.
		· Main Pipeline: Orchestrates the overall pre-training process, including data loading, optimizer setup, learning rate scheduling, and saving the best-performing model weights.
	· msfanet_stage2_finetune.py: Stage-2 fine-tuning script. It adapts the pre-trained MSFA-Net for the downstream binary classification task (BHB vs. Non-BHB) and saves the fine-tuned model weights. The script includes the following key modules:
		· Model Adaptation: Modifies the fully-connected classification head of the pre-trained MSFA-Net to output binary predictions.
		· Pre-trained Weight Loading: Loads the robust feature extraction weights saved from Stage-1 to initialize the network while excluding the previous classification head.
		· Stage2Dataset: A custom dataset module that maps specific multi-class labels into binary categories and automatically patches numerical anomalies in the input spectra.
		· W-LSCE Loss: Implements the Weighted Label-Smoothing Cross-Entropy loss by dynamically calculating logarithmic class weights to effectively handle the binary data imbalance.
		· Fine-tuning Pipeline: Orchestrates the downstream training process, tracking specific performance metrics to identify and save the optimal model for BHB identification.